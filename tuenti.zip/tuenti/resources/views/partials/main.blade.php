@extends('layout')

@section('titulo', 'Tuenti')

@section('contenido')
@include('partials.header')
<main>
    <div class="lateral-izq">
        <h2>-</h2>
    </div>
    <div class="central">
        @include('posts.create')
        @include('posts.index')
    </div>
    <div class="lateral-der">
        <h2>-</h2>
    </div>
</main>

@endsection
