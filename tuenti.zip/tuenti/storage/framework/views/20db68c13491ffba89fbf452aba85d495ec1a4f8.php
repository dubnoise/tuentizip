<?php $__env->startSection('titulo', 'Tuenti'); ?>

<?php $__env->startSection('contenido'); ?>
<?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<main>
    <div class="lateral-izq">
        <h2>-</h2>
    </div>
    <div class="central">
        <?php echo $__env->make('posts.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('posts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="lateral-der">
        <h2>-</h2>
    </div>
</main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tuenti\resources\views/partials/main.blade.php ENDPATH**/ ?>