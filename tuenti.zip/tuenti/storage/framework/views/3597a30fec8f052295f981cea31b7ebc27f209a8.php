<?php $__env->startSection('titulo', 'Tuenti'); ?>

<?php $__env->startSection('contenido'); ?>

<header>
    <?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</header>

<main>
    <div class="lateral-izq">
        <div class="profile-izq">
            <img src="img/blank-user.jpg" alt="user">
            <h3>Información</h3>
            <hr>

        </div>
    </div>
    <div class="central">

    </div>
    <div class="lateral-der">
        <h2>-</h2>
    </div>

</main>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tuenti\resources\views/profile.blade.php ENDPATH**/ ?>