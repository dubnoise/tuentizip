<?php $__env->startSection('titulo', 'Tuenti'); ?>

<?php $__env->startSection('contenido'); ?>

<header>
    <?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</header>

<main>
    <div class="lateral-izq">
        <h2>-</h2>
    </div>
    <div class="central">
        <div class="messages">
                <div class="message">
                    <img src=<?php echo e(asset('img/blank-user.jpg')); ?> alt="user">
                    <h4><?php echo e($message->content); ?></h4>
                </div>
        </div>
    </div>
    <div class="lateral-der">
        <h2>-</h2>
    </div>

</main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tuenti\resources\views/messages/show.blade.php ENDPATH**/ ?>