<?php $__env->startSection('titulo', 'Tuenti'); ?>

<?php $__env->startSection('contenido'); ?>

<header>
    <?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</header>

<main>
    <div class="lateral-izq">
        <div class="profile-izq">
            <img src=<?php echo e(asset('img/blank-user.jpg')); ?> alt="user">
            <h3>Información</h3>
            <hr>
            <ul>
                <li><b>Nombre:</b> <?php echo e($user->name); ?></li>
                <li><b>Apellidos:</b> <?php echo e($user->surname); ?></li>
                <li><b>País:</b> <?php echo e($user->country); ?></li>
                <li><b>Ciudad:</b> <?php echo e($user->city); ?></li>
                <li><b>Sexo:</b>
                    <?php if($user->genre != ""): ?>
                        <?php echo e($user->genre); ?>

                    <?php else: ?>
                        ¿?
                    <?php endif; ?>
                </li>
                <li><b>Fecha de nacimiento:</b> <?php echo e($user->birthdate); ?></li>
            </ul>
        </div>
    </div>
    <div class="central">

    </div>
    <div class="lateral-der">
        <h2>-</h2>
    </div>

</main>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tuenti\resources\views/users/show.blade.php ENDPATH**/ ?>