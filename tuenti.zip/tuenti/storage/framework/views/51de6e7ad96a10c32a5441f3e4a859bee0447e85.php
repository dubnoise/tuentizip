<form action=<?php echo e(route('posts.store')); ?> method="POST" class="form-estado">
    <?php echo csrf_field(); ?>

    <input type="hidden" name="user_id" value=<?php echo e(auth()->user()->id); ?>>
    <input type="text" name="content" placeholder="Actualiza tu estado" class="estado">
    <p id="estado-error">
        <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            Error: <?php echo e($message); ?>

        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </p>
    <div class="ultima-act">
        <p id="ult-act"><b>Última actualización: </b></p>
        <input type="submit" value="Guardar" class="guardar">
    </div>

</form>




<?php /**PATH C:\xampp\htdocs\tuenti\resources\views/posts/create.blade.php ENDPATH**/ ?>